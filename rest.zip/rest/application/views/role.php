<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require'header.php';
echo $contents;
//require'sidebar.php';
require'footer.php';